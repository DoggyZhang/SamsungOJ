document.write("<li><a href=loginpage.php>登录</a></li>&nbsp;<li><a href=registerpage.php>注册</a></li>&nbsp;");
document.getElementById("profile").innerHTML="登录";
